from ufos import *

# Test de la función lee_avistamientos


#Test de la función duracion_total

    
# Test de la función comentario_mas_largo



# Test de la función avistamientos_fechas



# Test de la función hora_mas_avistamientos









